var drx_8h =
[
    [ "dr_get_tls_field", "drx_8h.html#ga0d6964a67aa0fe1840aa7de8cdf0fe1b", null ],
    [ "dr_insert_read_tls_field", "drx_8h.html#gabb0fa2849dd0255e439794c6a212128c", null ],
    [ "dr_insert_write_tls_field", "drx_8h.html#ga273efb4ea5e7639e3d99ecbb2aa20cde", null ],
    [ "dr_set_tls_field", "drx_8h.html#gab859ebbb56a4335bd867a1f787ec9a2c", [
      [ "DRX_NOTE_NONE", "drx_8h.html#ggae4d5251432e1a9e6803c0240cc492e18a497edba924cd8898ce1e96744b655e34", null ],
      [ "DRX_COUNTER_64BIT", "drx_8h.html#gga7ff5f2dff38e7639981794c43dc9167ba507636af18a8858c214066682d013a1a", null ],
      [ "DRX_COUNTER_LOCK", "drx_8h.html#gga7ff5f2dff38e7639981794c43dc9167baa45e32a1d62398b84858de6759364688", null ]
    ] ],
    [ "drx_aflags_are_dead", "drx_8h.html#gae33a91872caa46e430d5d721af6d8c82", null ],
    [ "drx_exit", "drx_8h.html#ga996c662c089046984b64a627500748f5", null ],
    [ "drx_init", "drx_8h.html#gae0665a86427616ffc80c59375649e283", null ],
    [ "drx_insert_counter_update", "drx_8h.html#ga0c7f90fcd312ac9e8542535709a8b65a", null ],
    [ "drx_open_unique_appid_file", "drx_8h.html#gaa85537dd6726928bbd43a21dc8211a53", null ],
    [ "drx_open_unique_file", "drx_8h.html#gaa0a5fcca247de11374c3555a5326cba8", null ],
    [ "drx_register_soft_kills", "drx_8h.html#ga9348e840424caf0098a8b1ba69955864", null ],
    [ "drx_reserve_note_range", "drx_8h.html#ga3189cbfbf85d5c32965bd8a140b2c35e", null ]
];