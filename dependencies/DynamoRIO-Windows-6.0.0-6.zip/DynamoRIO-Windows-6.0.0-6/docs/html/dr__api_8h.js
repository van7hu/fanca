var dr__api_8h =
[
    [ "DYNAMORIO_API", "dr__api_8h.html#a042102fdc63bb745f34ad483fc8534fa", null ],
    [ "dr_client_main", "dr__api_8h.html#a2b938c98dd186cc94eef6880f9e3c3e9", null ],
    [ "dr_init", "dr__api_8h.html#a819eb581527829240bf227d5a8f98e4c", null ],
    [ "_USES_DR_VERSION_", "dr__api_8h.html#a3c7624762b308f07b2149e651c8603b2", null ]
];