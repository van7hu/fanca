var searchData=
[
  ['num_5fsimd_5fslots',['NUM_SIMD_SLOTS',['../dr__defines_8h.html#a1ae1127836840f9db6aae6d1b782c7b8',1,'dr_defines.h']]]
];
