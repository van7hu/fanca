var searchData=
[
  ['get_5fname',['get_name',['../classdroption__parser__t.html#aac7d13af70a4b01d662b309283d8fcad',1,'droption_parser_t']]],
  ['get_5fregister_5fname',['get_register_name',['../dr__ir__opnd_8h.html#a4b412ff3d08026f65ac44e1c6659a58a',1,'dr_ir_opnd.h']]],
  ['get_5fvalue',['get_value',['../classdroption__t.html#a906b15044f651dc6dacbeb2173772a36',1,'droption_t']]],
  ['get_5fx86_5fmode',['get_x86_mode',['../dr__ir__utils_8h.html#aa18c8ca0720c97403a0fa9371ae792e5',1,'dr_ir_utils.h']]]
];
