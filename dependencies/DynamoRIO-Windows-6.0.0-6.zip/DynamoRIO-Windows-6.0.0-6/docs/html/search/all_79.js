var searchData=
[
  ['year',['year',['../structdr__time__t.html#a200f3d9e7b728569503c5b8041883136',1,'dr_time_t']]]
];
