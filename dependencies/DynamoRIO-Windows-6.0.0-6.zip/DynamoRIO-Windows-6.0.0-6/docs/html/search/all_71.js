var searchData=
[
  ['q',['q',['../union__dr__simd__t.html#a162c7803f71554da5b3d28158e002997',1,'_dr_simd_t']]]
];
