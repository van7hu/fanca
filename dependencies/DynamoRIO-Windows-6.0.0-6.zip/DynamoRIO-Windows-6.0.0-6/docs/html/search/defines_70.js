var searchData=
[
  ['page_5fsize',['PAGE_SIZE',['../dr__proc_8h.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'dr_proc.h']]],
  ['pfx',['PFX',['../dr__defines_8h.html#a176e4c39a833f4d01f0ecd322c0f4343',1,'dr_defines.h']]],
  ['pidfmt',['PIDFMT',['../dr__defines_8h.html#a5d42a165683c52523356b380889803b5',1,'dr_defines.h']]],
  ['pifx',['PIFX',['../dr__defines_8h.html#a42ee5175c12e68f0d8ce3f67426853e8',1,'dr_defines.h']]],
  ['pre_5fsimd_5fpadding',['PRE_SIMD_PADDING',['../dr__defines_8h.html#a39cc32592e6a2b555a50cbe9e94381ea',1,'dr_defines.h']]],
  ['pre_5fxmm_5fpadding',['PRE_XMM_PADDING',['../dr__defines_8h.html#aaeb72915e4c71fc1fb346e9a52640e5b',1,'dr_defines.h']]],
  ['prefix_5fjcc_5fnot_5ftaken',['PREFIX_JCC_NOT_TAKEN',['../dr__ir__instr_8h.html#a0e6a144b4030140faa950fe65fe9002d',1,'dr_ir_instr.h']]],
  ['prefix_5fjcc_5ftaken',['PREFIX_JCC_TAKEN',['../dr__ir__instr_8h.html#a327356db32ce7a884e9a516b2d91b738',1,'dr_ir_instr.h']]],
  ['prefix_5flock',['PREFIX_LOCK',['../dr__ir__instr_8h.html#a697ecea613b828838ff6f08b88adf1d2',1,'dr_ir_instr.h']]],
  ['prefix_5fxacquire',['PREFIX_XACQUIRE',['../dr__ir__instr_8h.html#ac3c11ed8105a5cecf5345ab5262a784f',1,'dr_ir_instr.h']]],
  ['prefix_5fxrelease',['PREFIX_XRELEASE',['../dr__ir__instr_8h.html#aba06eaa86f6bbe22f58a1e2ddffb33da',1,'dr_ir_instr.h']]]
];
