var searchData=
[
  ['usage_5flong',['usage_long',['../classdroption__parser__t.html#a296ee6d73ca09454bd713c87b36af7d4',1,'droption_parser_t']]],
  ['usage_5fshort',['usage_short',['../classdroption__parser__t.html#a794defcf8a1dad193201c1a079659f91',1,'droption_parser_t']]]
];
