var searchData=
[
  ['prefetch',['prefetch',['../API_tutorial_prefetch1.html',1,'API_tutorial']]]
];
