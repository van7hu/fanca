var searchData=
[
  ['tool_5fnames',['tool_names',['../classdrgui__options__interface__t.html#a86855268f9cb7745629d2f781cac7c41',1,'drgui_options_interface_t::tool_names()'],['../classdrgui__tool__interface__t.html#ae87e4df804817768411bfa6e305404e5',1,'drgui_tool_interface_t::tool_names()']]]
];
