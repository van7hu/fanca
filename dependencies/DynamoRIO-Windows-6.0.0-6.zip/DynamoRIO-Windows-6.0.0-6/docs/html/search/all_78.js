var searchData=
[
  ['x64',['x64',['../struct__tracedump__file__header__t.html#a4e255a88f451148c000a742abc106860',1,'_tracedump_file_header_t::x64()'],['../struct__tracedump__trace__header__t.html#a4d86106601cee1e949cc2e885c9fc8af',1,'_tracedump_trace_header_t::x64()']]],
  ['xflags',['xflags',['../struct__dr__mcontext__t.html#a9b8818ea2b316e31fccd507793e9c8c0',1,'_dr_mcontext_t']]],
  ['xsp',['xsp',['../struct__dr__mcontext__t.html#a4e1c58a65a0b7aa6c55b5f18a2e2fd34',1,'_dr_mcontext_t']]]
];
