var searchData=
[
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['dynamorio_20system_20details',['DynamoRIO System Details',['../overview.html',1,'index']]],
  ['deployment',['Deployment',['../page_deploy.html',1,'index']]],
  ['dr_2e_20memory_20memory_20debugging_20tool',['Dr. Memory Memory Debugging Tool',['../page_drmemory.html',1,'page_tool']]],
  ['dynamorio_20option_20parser',['DynamoRIO Option Parser',['../page_droption.html',1,'page_ext']]],
  ['dynamorio_20extension_20utilities',['DynamoRIO eXtension utilities',['../page_drx.html',1,'page_ext']]],
  ['dynamorio_20extensions',['DynamoRIO Extensions',['../page_ext.html',1,'']]],
  ['dynamorio_2dbased_20tools',['DynamoRIO-Based Tools',['../page_tool.html',1,'']]]
];
