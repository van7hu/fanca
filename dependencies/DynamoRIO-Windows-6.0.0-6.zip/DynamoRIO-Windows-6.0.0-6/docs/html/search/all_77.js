var searchData=
[
  ['warn_5fimage_5fmachine_5ftype_5fmismatch_5fexe',['WARN_IMAGE_MACHINE_TYPE_MISMATCH_EXE',['../dr__inject_8h.html#a7e904aca534e09fccc4502dcc9ca5193',1,'dr_inject.h']]],
  ['write_5fsettings',['write_settings',['../classdrgui__options__interface__t.html#ab907b5a788448c576ed93b55194d9a75',1,'drgui_options_interface_t']]]
];
