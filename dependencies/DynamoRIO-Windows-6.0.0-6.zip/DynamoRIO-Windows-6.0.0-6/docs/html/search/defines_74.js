var searchData=
[
  ['tidfmt',['TIDFMT',['../dr__defines_8h.html#a80e139e8f2d2dd7d5d4a92f8ad7c6f4d',1,'dr_defines.h']]]
];
