var searchData=
[
  ['function_20wrapping_20and_20replacing',['Function Wrapping and Replacing',['../group__drwrap.html',1,'']]]
];
