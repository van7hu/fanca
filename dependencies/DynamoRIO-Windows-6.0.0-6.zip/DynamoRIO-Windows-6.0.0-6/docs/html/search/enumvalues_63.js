var searchData=
[
  ['cache_5fsize_5f128_5fkb',['CACHE_SIZE_128_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfad9093f90f2acc46a44cb325580064b93',1,'dr_proc.h']]],
  ['cache_5fsize_5f16_5fkb',['CACHE_SIZE_16_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa8002cfc04251e85a48cd4062ce78029d',1,'dr_proc.h']]],
  ['cache_5fsize_5f1_5fmb',['CACHE_SIZE_1_MB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa58dea49b51e5168e79577f232e328011',1,'dr_proc.h']]],
  ['cache_5fsize_5f256_5fkb',['CACHE_SIZE_256_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa592f2022f18b346b1cb8f3bedd09d31e',1,'dr_proc.h']]],
  ['cache_5fsize_5f2_5fmb',['CACHE_SIZE_2_MB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa46ac784cfe39e0369ebfb5ece5c0dfb7',1,'dr_proc.h']]],
  ['cache_5fsize_5f32_5fkb',['CACHE_SIZE_32_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfaa18ec5dea3a3987e8d13ed4f7bbf972a',1,'dr_proc.h']]],
  ['cache_5fsize_5f512_5fkb',['CACHE_SIZE_512_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa593e599689231f45277e4d1a5511eec0',1,'dr_proc.h']]],
  ['cache_5fsize_5f64_5fkb',['CACHE_SIZE_64_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa18362f194fca19849c7426fa30926f21',1,'dr_proc.h']]],
  ['cache_5fsize_5f8_5fkb',['CACHE_SIZE_8_KB',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa39df034a5ced0be40065bcb55fb9f942',1,'dr_proc.h']]],
  ['cache_5fsize_5funknown',['CACHE_SIZE_UNKNOWN',['../dr__proc_8h.html#abde92db21512f07aaf05d073c43832dfa33d137f8dcd660a19592fb6c76007d93',1,'dr_proc.h']]]
];
