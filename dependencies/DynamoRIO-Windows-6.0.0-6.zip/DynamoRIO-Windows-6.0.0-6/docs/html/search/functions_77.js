var searchData=
[
  ['write_5fsettings',['write_settings',['../classdrgui__options__interface__t.html#ab907b5a788448c576ed93b55194d9a75',1,'drgui_options_interface_t']]]
];
