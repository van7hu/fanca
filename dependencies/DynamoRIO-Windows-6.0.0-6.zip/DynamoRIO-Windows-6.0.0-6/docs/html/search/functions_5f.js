var searchData=
[
  ['_5f_5fwrap_5fcalloc',['__wrap_calloc',['../dr__tools_8h.html#a818524883cd69709fe0e3499d6748d14',1,'dr_tools.h']]],
  ['_5f_5fwrap_5ffree',['__wrap_free',['../dr__tools_8h.html#a82dca5b3d5bfbd3de8891502badd861e',1,'dr_tools.h']]],
  ['_5f_5fwrap_5fmalloc',['__wrap_malloc',['../dr__tools_8h.html#a3687f50774c89e7a09833a71adbb7771',1,'dr_tools.h']]],
  ['_5f_5fwrap_5frealloc',['__wrap_realloc',['../dr__tools_8h.html#adcaad79adf4fc109015dd6a2d49b9031',1,'dr_tools.h']]]
];
