var searchData=
[
  ['umbra_3a_20shadow_20memory_20extension',['Umbra: Shadow Memory Extension',['../page_drmf_umbra.html',1,'page_ext']]],
  ['usage_20model_20for_20dynamorio',['Usage Model for DynamoRIO',['../using.html',1,'index']]]
];
