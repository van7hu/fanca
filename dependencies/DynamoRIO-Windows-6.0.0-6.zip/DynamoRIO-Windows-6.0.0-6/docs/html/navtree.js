var NAVTREE =
[
  [ "DynamoRIO API", "index.html", [
    [ "The DynamoRIO API", "index.html", null ],
    [ "Deployment", "page_deploy.html", [
      [ "Windows Deployment", "page_deploy.html#win_deploy", null ],
      [ "Linux Deployment", "page_deploy.html#lin_deploy", null ],
      [ "Passing Options to Clients", "page_deploy.html#client_ops", null ],
      [ "Multiple Clients", "page_deploy.html#multi_client", null ],
      [ "End-User Tools", "page_deploy.html#tool_frontend", null ]
    ] ],
    [ "Usage Model for DynamoRIO", "using.html", [
      [ "Common Events", "using.html#sec_events", null ],
      [ "Common Utilities", "using.html#sec_utils", null ],
      [ "64-Bit Reachability", "using.html#sec_64bit_reach", null ],
      [ "String Encoding", "using.html#sec_utf8", null ],
      [ "Building a Client", "using.html#sec_build", null ],
      [ "DynamoRIO Extensions", "using.html#sec_extensions", null ],
      [ "Using External Libraries", "using.html#sec_extlibs", [
        [ "Avoid Alertable System Calls", "using.html#sec_alertable", null ],
        [ "DynamoRIO Library Search Paths", "using.html#sec_rpath", null ],
        [ "Deliberately Invoking Application Routines", "using.html#subsec_avoid_redir", null ],
        [ "When Private Loader is Disabled", "using.html#subsec_no_loader", null ],
        [ "C++ Clients", "using.html#subsec_cpp", null ]
      ] ],
      [ "Communication", "using.html#sec_comm", null ],
      [ "Annotations", "using.html#sec_annotations", [
        [ "Annotating an Application", "using.html#subsec_annotate_app", null ],
        [ "Instrumenting Annotations", "using.html#subsec_instr_annotations", null ],
        [ "Creating Custom Annotations", "using.html#subsec_create_annotations", null ]
      ] ],
      [ "Fine-Tuning DynamoRIO: Runtime Parameters", "using.html#sec_options", null ],
      [ "Diagnosing and Reporting Problems", "using.html#sec_debugging", [
        [ "Obtaining Help and Reporting Problems", "using.html#sec_reporting", null ],
        [ "Troubleshooting", "using.html#sec_diagnosing", null ],
        [ "Using Debuggers", "using.html#sec_using_debugger", null ]
      ] ]
    ] ],
    [ "Code Manipulation API", "API_BT.html", [
      [ "Instruction Representation", "API_BT.html#sec_IR", null ],
      [ "Events", "API_BT.html#sec_events_bt", [
        [ "Transformation Versus Execution Time", "API_BT.html#sec_control_points", null ],
        [ "Basic Block Creation", "API_BT.html#sec_events_bb", null ],
        [ "Application Versus Meta Instructions", "API_BT.html#sec_Meta", null ],
        [ "Trace Creation", "API_BT.html#sec_events_trace", null ],
        [ "State Restoration", "API_BT.html#sec_events_translation", null ],
        [ "Basic Block and Trace Deletion", "API_BT.html#sec_events_del", null ],
        [ "Special System Calls", "API_BT.html#sec_events_wow64", null ]
      ] ],
      [ "Decoding and Encoding", "API_BT.html#sec_decode", [
        [ "Decoding", "API_BT.html#sec_Decoding", null ],
        [ "Instruction Generation", "API_BT.html#sec_InstrGen", null ],
        [ "Encoding", "API_BT.html#sec_Encoding", null ],
        [ "Disassembly", "API_BT.html#sec_disasm", null ]
      ] ],
      [ "Instruction Set Modes", "API_BT.html#sec_isa", [
        [ "64-bit Versus 32-bit Instructions", "API_BT.html#sec_64bit", null ],
        [ "Thumb Mode Addresses", "API_BT.html#sec_thumb", null ]
      ] ],
      [ "Utilities", "API_BT.html#sec_IR_utils", [
        [ "Clean Calls", "API_BT.html#sec_clean_call", null ],
        [ "State Preservation", "API_BT.html#sec_state", null ],
        [ "Branch Instrumentation", "API_BT.html#sec_branch_instru", null ],
        [ "Dynamic Instrumentation", "API_BT.html#sec_adaptive", null ],
        [ "Custom Traces", "API_BT.html#sec_custom_traces", null ]
      ] ],
      [ "Register Stolen by DynamoRIO", "API_BT.html#sec_reg_stolen", null ],
      [ "State Translation", "API_BT.html#sec_translation", null ],
      [ "Conditionally Executed Instructions", "API_BT.html#sec_predication", null ],
      [ "Persisting Code", "API_BT.html#sec_pcache", null ],
      [ "Running a Subset of an Application", "API_BT.html#sec_startstop", null ]
    ] ],
    [ "IA-32/AMD64/ARM Disassembly Library", "page_standalone.html", [
      [ "Using DynamoRIO as a Standalone Library", "page_standalone.html#sec_standalone", [
        [ "Re-Relativization of Jumps and Calls", "page_standalone.html#sec_relativize", null ]
      ] ],
      [ "DynamoRIO Shared Library Issues", "page_standalone.html#sec_standalone_shared", null ]
    ] ],
    [ "API Usage Tutorial", "API_tutorial.html", "API_tutorial" ],
    [ "Sample Use Cases", "API_samples.html", [
      [ "List of Samples", "API_samples.html#sample_list", null ],
      [ "Discussion of Selected Samples", "API_samples.html#bt_examples", [
        [ "Instruction Counting", "API_samples.html#sec_ex1", null ],
        [ "Instruction Profiling", "API_samples.html#sec_ex2", null ],
        [ "Modifying Existing Instrumentation", "API_samples.html#sec_ex3", null ],
        [ "Optimization", "API_samples.html#sec_ex4", null ],
        [ "Custom Tracing", "API_samples.html#sec_ex5", null ],
        [ "Use of Floating Point Operation in a Client", "API_samples.html#sec_ex6", null ],
        [ "Use of Custom Client Statistics with the Windows GUI", "API_samples.html#sec_drstats", null ],
        [ "Use of Standalone API", "API_samples.html#sec_ex8", null ]
      ] ]
    ] ],
    [ "DynamoRIO System Details", "overview.html", "overview" ],
    [ "Release Notes for Version 6.0.0", "release_notes.html", [
      [ "Distribution Contents", "release_notes.html#sec_package", null ],
      [ "Changes Since Prior Releases", "release_notes.html#sec_changes", null ],
      [ "Limitations", "release_notes.html#sec_limits", [
        [ "Client Limitations", "release_notes.html#sec_limit_clients", null ],
        [ "Platform Limitations", "release_notes.html#sec_limit_platforms", null ],
        [ "Performance Limitations", "release_notes.html#sec_limit_perf", null ],
        [ "Deployment Limitations", "release_notes.html#sec_limit_deploy", null ]
      ] ],
      [ "Plans for Future Releases", "release_notes.html#sec_future", null ]
    ] ],
    [ "Licenses", "page_license.html", [
      [ "Primary DynamoRIO License: BSD", "page_license.html#sec_bsd", null ],
      [ "libelftc License", "page_license.html#sec_libelftc", null ],
      [ "Certain Extensions are instead under the LGPL 2.1 License", "page_license.html#sec_lgpl_licenses", null ]
    ] ],
    [ "DynamoRIO Extensions", "page_ext.html", "page_ext" ],
    [ "DynamoRIO-Based Tools", "page_tool.html", "page_tool" ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "DynamoRIO Extension Details", "modules.html", "modules" ],
    [ "Data Structures", null, [
      [ "Data Structures", "annotated.html", "annotated" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ],
    [ "DynamoRIO Home Page", "^http://www.dynamorio.org", null ]
  ] ]
];

var NAVTREEINDEX =
[
"API_BT.html",
"dr__defines_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7",
"dr__ir__instr_8h.html#a241f4fe5f01af11fe8e9489fcf84ab4a",
"dr__ir__instrlist_8h.html#ae8313ff5985340de519dfe4cc7555c60",
"dr__ir__opcodes__arm_8h.html#abed82baf7f470b522273a3e37c24c600a3bd2bb676cd75b2fddd94b05b6dfce94",
"dr__ir__opcodes__arm_8h.html#abed82baf7f470b522273a3e37c24c600a807b5b1c2a6f0d8336a57459508d89e5",
"dr__ir__opcodes__arm_8h.html#abed82baf7f470b522273a3e37c24c600ac94b8e74a7fe407f09479d769d7b6443",
"dr__ir__opcodes__x86_8h.html#a7f8b1d83c717747d470b14a6b1710aaa",
"dr__ir__opcodes__x86_8h.html#ab04a0655cd1e3bcac5e8f48c18df1a57a32177b074630380042d18a48b39c2354",
"dr__ir__opcodes__x86_8h.html#ab04a0655cd1e3bcac5e8f48c18df1a57a6cc226f415bca47a9d78af526ff89d56",
"dr__ir__opcodes__x86_8h.html#ab04a0655cd1e3bcac5e8f48c18df1a57aa520641bd92242a021c36a20934c7bd5",
"dr__ir__opcodes__x86_8h.html#ab04a0655cd1e3bcac5e8f48c18df1a57ae58a146be10ca0671f758985edfd904f",
"dr__ir__opnd_8h.html#a385c44f6fb256e5716a2302a5b940388a7deb6444d23c983c69cd4067781d6be8",
"dr__ir__opnd_8h.html#abc5c98fcc1211af2b80116dd6e0a035dab55fcbee05cb366e2f7dd3dd5754deb7",
"dr__proc_8h.html#a5e226019d68bd13050692da392f6c4bfa53a91f784ce997e5eebe9d24b4fdec0f",
"dr__tools_8h.html#a724aa7f7e87a604071fffa0a01925bf0",
"drmgr_8h.html#ga984ae18ed26a72c84a0fcaaaf44e2343",
"functions_0x6c.html",
"group__drreg.html#ggad5b7a7a020d7206b11e61e7cdae02ee9ab62388bb72ad127e07c1ffafb213cb6e",
"page_drx.html",
"structdr__time__t.html#a5e8ddf211fa32449578e676b9d3b7eb5",
];

var navTreeSubIndices = new Array();

function getData(varName)
{
  var i = varName.lastIndexOf('/');
  var n = i>=0 ? varName.substring(i+1) : varName;
  return eval(n.replace(/\-/g,'_'));
}

function stripPath(uri)
{
  return uri.substring(uri.lastIndexOf('/')+1);
}

function stripPath2(uri)
{
  var i = uri.lastIndexOf('/');
  var s = uri.substring(i+1);
  var m = uri.substring(0,i+1).match(/\/d\w\/d\w\w\/$/);
  return m ? uri.substring(i-6) : s;
}

function getScript(scriptName,func,show)
{
  var head = document.getElementsByTagName("head")[0]; 
  var script = document.createElement('script');
  script.id = scriptName;
  script.type = 'text/javascript';
  script.onload = func; 
  script.src = scriptName+'.js'; 
  if ($.browser.msie && $.browser.version<=8) { 
    // script.onload does work with older versions of IE
    script.onreadystatechange = function() {
      if (script.readyState=='complete' || script.readyState=='loaded') { 
        func(); if (show) showRoot(); 
      }
    }
  }
  head.appendChild(script); 
}

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode) {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  imgNode.width = 16;
  imgNode.height = 22;
  if (level==0 && node.childrenData) {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() {
      if (node.expanded) {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast) {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        } else {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } else {
        expandNode(o, node, false, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  } else {
    domNode.appendChild(imgNode);
  }
  if (level==0) {
    if (node.isLast) {
      if (node.childrenData) {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      } else {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    } else {
      if (node.childrenData) {
        imgNode.src = node.relpath+"ftv2pnode.png";
      } else {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  } else {
    if (node.isLast) {
      imgNode.src = node.relpath+"ftv2blank.png";
    } else {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  node.expanded = false;
  a.appendChild(node.label);
  if (link) {
    var url;
    if (link.substring(0,1)=='^') {
      url = link.substring(1);
      link = url;
    } else {
      url = node.relpath+link;
    }
    a.className = stripPath(link.replace('#',':'));
    if (link.indexOf('#')!=-1) {
      var aname = '#'+link.split('#')[1];
      var srcPage = stripPath($(location).attr('pathname'));
      var targetPage = stripPath(link.split('#')[0]);
      a.href = srcPage!=targetPage ? url : '#';
      a.onclick = function(){
        if (!$(a).parent().parent().hasClass('selected'))
        {
          $('.item').removeClass('selected');
          $('.item').removeAttr('id');
          $(a).parent().parent().addClass('selected');
          $(a).parent().parent().attr('id','selected');
        }
        var pos, anchor = $(aname), docContent = $('#doc-content');
        if (anchor.parent().attr('class')=='memItemLeft') {
          pos = anchor.parent().position().top;
        } else if (anchor.position()) {
          pos = anchor.position().top;
        }
        if (pos) {
          var dist = Math.abs(Math.min(
                     pos-docContent.offset().top,
                     docContent[0].scrollHeight-
                     docContent.height()-docContent.scrollTop()));
          docContent.animate({
            scrollTop: pos + docContent.scrollTop() - docContent.offset().top
          },Math.max(50,Math.min(500,dist)),function(){
            window.location.replace(aname);
          });
        }
      };
    } else {
      a.href = url;
    }
  } else {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() {
    if (!node.childrenUL) {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  (function (){ // retry until we can scroll to the selected item
    try {
      var navtree=$('#nav-tree');
      navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
    } catch (err) {
      setTimeout(arguments.callee, 0);
    }
  })();
}

function expandNode(o, node, imm, showRoot)
{
  if (node.childrenData && !node.expanded) {
    if (typeof(node.childrenData)==='string') {
      var varName    = node.childrenData;
      getScript(node.relpath+varName,function(){
        node.childrenData = getData(varName);
        expandNode(o, node, imm, showRoot);
      }, showRoot);
    } else {
      if (!node.childrenVisited) {
        getNode(o, node);
      } if (imm || ($.browser.msie && $.browser.version>8)) { 
        // somehow slideDown jumps to the start of tree for IE9 :-(
        $(node.getChildrenUL()).show();
      } else {
        $(node.getChildrenUL()).slideDown("fast");
      }
      if (node.isLast) {
        node.plus_img.src = node.relpath+"ftv2mlastnode.png";
      } else {
        node.plus_img.src = node.relpath+"ftv2mnode.png";
      }
      node.expanded = true;
    }
  }
}

function glowEffect(n,duration)
{
  n.addClass('glow').delay(duration).queue(function(next){
    $(this).removeClass('glow');next();
  });
}

function highlightAnchor()
{
  var anchor = $($(location).attr('hash'));
  if (anchor.parent().attr('class')=='memItemLeft'){
    var rows = $('.memberdecls tr[class$="'+
               window.location.hash.substring(1)+'"]');
    glowEffect(rows.children(),300); // member without details
  } else if (anchor.parents().slice(2).prop('tagName')=='TR') {
    glowEffect(anchor.parents('div.memitem'),1000); // enum value
  } else if (anchor.parent().is(":header")) {
    glowEffect(anchor.parent(),1000); // section header
  } else {
    glowEffect(anchor.next(),1000); // normal member
  }
}

function selectAndHighlight(n)
{
  var a;
  if ($(location).attr('hash')) {
    var link=stripPath($(location).attr('pathname'))+':'+
      $(location).attr('hash').substring(1);
    a=$('.item a[class$="'+link+'"]');
  }
  if (a && a.length) {
    a.parent().parent().addClass('selected');
    a.parent().parent().attr('id','selected');
    highlightAnchor();
  } else if (n) {
    $(n.itemDiv).addClass('selected');
    $(n.itemDiv).attr('id','selected');
  }
  showRoot();
}

function showNode(o, node, index)
{
  if (node && node.childrenData) {
    if (typeof(node.childrenData)==='string') {
      var varName    = node.childrenData;
      getScript(node.relpath+varName,function(){
        node.childrenData = getData(varName);
        showNode(o,node,index);
      },true);
    } else {
      if (!node.childrenVisited) {
        getNode(o, node);
      }
      $(node.getChildrenUL()).show();
      if (node.isLast) {
        node.plus_img.src = node.relpath+"ftv2mlastnode.png";
      } else {
        node.plus_img.src = node.relpath+"ftv2mnode.png";
      }
      node.expanded = true;
      var n = node.children[o.breadcrumbs[index]];
      if (index+1<o.breadcrumbs.length) {
        showNode(o,n,index+1);
      } else {
        if (typeof(n.childrenData)==='string') {
          var varName = n.childrenData;
          getScript(n.relpath+varName,function(){
            n.childrenData = getData(varName);
            node.expanded=false;
            showNode(o,node,index); // retry with child node expanded
          },true);
        } else {
          var rootBase = o.toroot.replace(/\..+$/, '');
          if (rootBase=="index" || rootBase=="pages") {
            expandNode(o, n, true, true);
          }
          selectAndHighlight(n);
        }
      }
    }
  } else {
    selectAndHighlight();
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
      i==l);
  }
}

function gotoNode(o,subIndex,root,hash,relpath)
{
  var nti = navTreeSubIndices[subIndex][root+hash];
  o.breadcrumbs = nti ? nti : navTreeSubIndices[subIndex][root];
  if (!o.breadcrumbs && root!=NAVTREE[0][1]) { // fallback: show index
    navTo(o,NAVTREE[0][1],"",relpath);
    $('.item').removeClass('selected');
    $('.item').removeAttr('id');
  }
  if (o.breadcrumbs) {
    o.breadcrumbs.unshift(0); // add 0 for root node
    showNode(o, o.node, 0);
  }
}

function navTo(o,root,hash,relpath)
{
  if (hash.match(/^#l\d+$/)) {
    var anchor=$('a[name='+hash.substring(1)+']');
    glowEffect(anchor.parent(),1000); // line number
    hash=''; // strip line number anchors
  }
  var url=root+hash;
  var i=-1;
  while (NAVTREEINDEX[i+1]<=url) i++;
  if (navTreeSubIndices[i]) {
    gotoNode(o,i,root,hash,relpath)
  } else {
    getScript(relpath+'navtreeindex'+i,function(){
      navTreeSubIndices[i] = eval('NAVTREEINDEX'+i);
      if (navTreeSubIndices[i]) {
        gotoNode(o,i,root,hash,relpath);
      }
    },true);
  }
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;
  o.node.expanded = false;
  o.node.isLast = true;
  o.node.plus_img = document.createElement("img");
  o.node.plus_img.src = relpath+"ftv2pnode.png";
  o.node.plus_img.width = 16;
  o.node.plus_img.height = 22;

  navTo(o,toroot,window.location.hash,relpath);

  $(window).bind('hashchange', function(){
     if (window.location.hash && window.location.hash.length>1){
       var a;
       if ($(location).attr('hash')){
         var clslink=stripPath($(location).attr('pathname'))+':'+
                               $(location).attr('hash').substring(1);
         a=$('.item a[class$="'+clslink+'"]');
       }
       if (a==null || !$(a).parent().parent().hasClass('selected')){
         $('.item').removeClass('selected');
         $('.item').removeAttr('id');
       }
       var link=stripPath2($(location).attr('pathname'));
       navTo(o,link,$(location).attr('hash'),relpath);
     }
  })

  $(window).load(showRoot);

        var imgdiv = document.createElement("div");
        document.getElementById("nav-tree-contents").appendChild(imgdiv);
        var img = document.createElement("img");
        imgdiv.appendChild(img);
        img.src = "drlogo.png";
        img.style.marginLeft = "80px";
        img.style.marginTop = "30px";
    
}