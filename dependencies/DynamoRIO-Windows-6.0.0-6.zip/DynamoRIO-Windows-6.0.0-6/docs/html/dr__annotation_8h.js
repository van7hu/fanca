var dr__annotation_8h =
[
    [ "_dr_vg_client_request_t", "struct__dr__vg__client__request__t.html", "struct__dr__vg__client__request__t" ],
    [ "dr_annotation_calling_convention_t", "dr__annotation_8h.html#addc1848592c2b6df346f1714b3d4ba4a", null ],
    [ "dr_valgrind_request_id_t", "dr__annotation_8h.html#a62debfb391eab76bde7a3e024892f78c", null ],
    [ "dr_vg_client_request_t", "dr__annotation_8h.html#a642e149d8e01ba7b38222f311e5d23eb", [
      [ "DR_VG_NUM_ARGS", "dr__annotation_8h.html#a06fc87d81c62e9abb8790b6e5713c55baca95e9de03395b913e665e6d98f48753", null ]
    ] ],
    [ "_dr_annotation_calling_convention_t", "dr__annotation_8h.html#af8841be8a34cea641a506612a365a106", [
      [ "DR_ANNOTATION_CALL_TYPE_FASTCALL", "dr__annotation_8h.html#af8841be8a34cea641a506612a365a106a857c8e97407d411a69b98c7e1ae0f530", null ],
      [ "DR_ANNOTATION_CALL_TYPE_VARARG", "dr__annotation_8h.html#af8841be8a34cea641a506612a365a106afc2da0008a6667e81f9b475167a15e3f", null ],
      [ "DR_ANNOTATION_CALL_TYPE_LAST", "dr__annotation_8h.html#af8841be8a34cea641a506612a365a106af9677932db07e97067924938c8f320f4", null ]
    ] ],
    [ "_dr_valgrind_request_id_t", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19", [
      [ "DR_VG_ID__RUNNING_ON_VALGRIND", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19af5cbf8fd188fd96ac3c06ab4f3e06c4a", null ],
      [ "DR_VG_ID__DO_LEAK_CHECK", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19aeac89b5320d10b8ff4e6be192458ffbe", null ],
      [ "DR_VG_ID__MAKE_MEM_DEFINED_IF_ADDRESSABLE", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19a4a3a7646cd176f003a2199d87f25f1d0", null ],
      [ "DR_VG_ID__DISCARD_TRANSLATIONS", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19a70fbb5f2728906ed5fef0409e06b75f1", null ],
      [ "DR_VG_ID__LAST", "dr__annotation_8h.html#a991e19026e652477136bd555de560c19ade400c6f5dbd4b8faa24da149b16e05d", null ]
    ] ],
    [ "dr_annotation_register_call", "dr__annotation_8h.html#a3614697e9fd7997c3303784a571fae1a", null ],
    [ "dr_annotation_register_return", "dr__annotation_8h.html#aa1cd1500b1206677d36ef5b833a835b9", null ],
    [ "dr_annotation_register_valgrind", "dr__annotation_8h.html#a498a6c747a98a0fbe9dfada715e50e1e", null ],
    [ "dr_annotation_set_return_value", "dr__annotation_8h.html#ab32f294e5bfa81b8464dc8bc0e0d4d3e", null ],
    [ "dr_annotation_unregister_call", "dr__annotation_8h.html#ab033cbbd72964514b40f016c7ce03451", null ],
    [ "dr_annotation_unregister_return", "dr__annotation_8h.html#a932ab4c2230b52f15166fd299cf195b8", null ],
    [ "dr_annotation_unregister_valgrind", "dr__annotation_8h.html#a705df396cf7a24a83ae5b2819703638a", null ]
];