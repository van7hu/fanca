var classdrgui__tool__interface__t =
[
    [ "create_instance", "classdrgui__tool__interface__t.html#aa43851da86d170f6abf5c8c4ddbf05b6", null ],
    [ "create_options_page", "classdrgui__tool__interface__t.html#a265d432ab2e13c15ef32a2075530afd3", null ],
    [ "new_instance_requested", "classdrgui__tool__interface__t.html#a096530fcd69d8fd3aa51ab658101ce41", null ],
    [ "open_file", "classdrgui__tool__interface__t.html#a00ed37d232687f373e94535f130bcf75", null ],
    [ "tool_names", "classdrgui__tool__interface__t.html#ae87e4df804817768411bfa6e305404e5", null ]
];