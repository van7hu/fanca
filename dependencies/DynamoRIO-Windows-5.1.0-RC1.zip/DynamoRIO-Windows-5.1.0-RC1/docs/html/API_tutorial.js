var API_tutorial =
[
    [ "API_tutorial_bbdynsize1", "API_tutorial_bbdynsize1.html", "API_tutorial_bbdynsize1" ],
    [ "API_tutorial_steal_reg1", "API_tutorial_steal_reg1.html", null ],
    [ "API_tutorial_prefetch1", "API_tutorial_prefetch1.html", null ]
];