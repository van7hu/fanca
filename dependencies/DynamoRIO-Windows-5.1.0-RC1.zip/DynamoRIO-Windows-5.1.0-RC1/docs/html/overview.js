var overview =
[
    [ "Introduction", "overview.html#sec_intro", null ],
    [ "System Operation", "overview.html#sec_system", null ],
    [ "Transparency", "overview.html#sec_sys_transp", null ],
    [ "References", "overview.html#sec_refs", null ],
    [ "Client Transparency", "transparency.html", [
      [ "Resource Usage Conflicts", "transparency.html#sec_trans_resource", null ],
      [ "Leaving the Application Unchanged When Possible", "transparency.html#sec_trans_unmod", null ],
      [ "Pretending The Application Is Unchanged When It Is Not", "transparency.html#sec_trans_pretend", null ],
      [ "Alertable System Calls", "transparency.html#sec_trans_alertable", null ]
    ] ]
];