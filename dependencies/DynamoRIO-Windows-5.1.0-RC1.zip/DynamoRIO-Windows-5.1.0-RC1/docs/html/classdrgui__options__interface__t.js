var classdrgui__options__interface__t =
[
    [ "read_settings", "classdrgui__options__interface__t.html#adfcc7d6ec802d978bac61fd6a1211de9", null ],
    [ "tool_names", "classdrgui__options__interface__t.html#a86855268f9cb7745629d2f781cac7c41", null ],
    [ "write_settings", "classdrgui__options__interface__t.html#ab907b5a788448c576ed93b55194d9a75", null ]
];