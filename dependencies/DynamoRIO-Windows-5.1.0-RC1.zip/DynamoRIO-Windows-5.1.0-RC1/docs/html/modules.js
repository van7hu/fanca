var modules =
[
    [ "Container Data Structures", "group__drcontainers.html", "group__drcontainers" ],
    [ "Multi-Instrumentation Manager", "group__drmgr.html", "group__drmgr" ],
    [ "Symbol Access Library", "group__drsyms.html", "group__drsyms" ],
    [ "Instrumentation Utilities", "group__drutil.html", "group__drutil" ],
    [ "Function Wrapping and Replacing", "group__drwrap.html", "group__drwrap" ],
    [ "DynamoRIO eXtension utilities", "group__drx.html", "group__drx" ]
];