var drx_8h =
[
    [ "drx_aflags_are_dead", "drx_8h.html#gae33a91872caa46e430d5d721af6d8c82", null ],
    [ "drx_exit", "drx_8h.html#ga996c662c089046984b64a627500748f5", null ],
    [ "drx_init", "drx_8h.html#gae0665a86427616ffc80c59375649e283", null ],
    [ "drx_insert_counter_update", "drx_8h.html#gad92376389835d11ed759deb59d8888f6", null ],
    [ "drx_open_unique_appid_file", "drx_8h.html#gaa85537dd6726928bbd43a21dc8211a53", null ],
    [ "drx_open_unique_file", "drx_8h.html#gaa0a5fcca247de11374c3555a5326cba8", null ],
    [ "drx_register_soft_kills", "drx_8h.html#ga9348e840424caf0098a8b1ba69955864", null ],
    [ "drx_reserve_note_range", "drx_8h.html#ga3189cbfbf85d5c32965bd8a140b2c35e", null ]
];