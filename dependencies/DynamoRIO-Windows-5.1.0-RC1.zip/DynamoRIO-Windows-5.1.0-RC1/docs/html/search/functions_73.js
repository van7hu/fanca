var searchData=
[
  ['set_5fx86_5fmode',['set_x86_mode',['../dr__ir__utils_8h.html#adf9a4f63eafc7f9725f7d5bf1725ab5c',1,'dr_ir_utils.h']]],
  ['stri_5feq',['stri_eq',['../group__drcontainers.html#gab341e9839c6cbd89a5a442df73468f5f',1,'hashtable.h']]]
];
