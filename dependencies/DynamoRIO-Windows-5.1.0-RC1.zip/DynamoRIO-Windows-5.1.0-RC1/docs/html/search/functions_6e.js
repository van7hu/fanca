var searchData=
[
  ['new_5finstance_5frequested',['new_instance_requested',['../classdrgui__tool__interface__t.html#a096530fcd69d8fd3aa51ab658101ce41',1,'drgui_tool_interface_t']]]
];
