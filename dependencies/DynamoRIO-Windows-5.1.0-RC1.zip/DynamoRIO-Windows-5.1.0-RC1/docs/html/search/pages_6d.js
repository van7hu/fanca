var searchData=
[
  ['multi_2dinstrumentation_20manager',['Multi-Instrumentation Manager',['../page_drmgr.html',1,'page_ext']]]
];
