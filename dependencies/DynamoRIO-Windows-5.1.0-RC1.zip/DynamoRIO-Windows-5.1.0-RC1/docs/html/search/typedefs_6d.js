var searchData=
[
  ['module_5fnames_5ft',['module_names_t',['../dr__tools_8h.html#a8d2fef062beef2b521283369e0108282',1,'dr_tools.h']]],
  ['module_5fsegment_5fdata_5ft',['module_segment_data_t',['../dr__tools_8h.html#ab49d9cfe4b0a8495532e5e4189515e83',1,'dr_tools.h']]]
];
