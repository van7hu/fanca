var searchData=
[
  ['client_5fid_5ft',['client_id_t',['../dr__defines_8h.html#a68540a70b4f8150a4fe6dcec91bf8825',1,'dr_defines.h']]]
];
