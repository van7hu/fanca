var searchData=
[
  ['reg_5fid_5ft',['reg_id_t',['../dr__ir__opnd_8h.html#a0ee0a856086c863d56ad515919e03136',1,'dr_ir_opnd.h']]]
];
