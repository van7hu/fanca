var searchData=
[
  ['feature_5fbit_5ft',['feature_bit_t',['../dr__proc_8h.html#a5e226019d68bd13050692da392f6c4bf',1,'dr_proc.h']]]
];
