var searchData=
[
  ['value',['value',['../struct__dr__syscall__result__info__t.html#a4f3fef7d8e374b0ba9f0926d8e8fa3ec',1,'_dr_syscall_result_info_t']]],
  ['vendor_5famd',['VENDOR_AMD',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da98f56d8179428f9ae8a673281e490fb7',1,'dr_proc.h']]],
  ['vendor_5farm',['VENDOR_ARM',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da2ad2ea2a2c40658bd0ded140cc6b8819',1,'dr_proc.h']]],
  ['vendor_5fintel',['VENDOR_INTEL',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da0ff85c91faaad5edc40b8b13bf5872a9',1,'dr_proc.h']]],
  ['vendor_5funknown',['VENDOR_UNKNOWN',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da366adf423d8e0771406dc7be013f0fce',1,'dr_proc.h']]],
  ['version',['version',['../union__version__number__t.html#ad1ae77c54e6ead8c94ee671258f914e8',1,'_version_number_t::version()'],['../struct__dr__os__version__info__t.html#a922ca431c88fcc0aab87da9a2b44ac91',1,'_dr_os_version_info_t::version()'],['../struct__tracedump__file__header__t.html#a3db1135276abc501651424397bb49242',1,'_tracedump_file_header_t::version()']]],
  ['version_5fnumber_5ft',['version_number_t',['../dr__tools_8h.html#aee552e6017b95b4708435b9467223d98',1,'dr_tools.h']]],
  ['version_5fparts',['version_parts',['../union__version__number__t.html#ae05a971826365b811bea6e5263aa3fba',1,'_version_number_t']]],
  ['version_5fuint',['version_uint',['../union__version__number__t.html#aac75a881d4d0041d97347cea8a5000b5',1,'_version_number_t']]]
];
