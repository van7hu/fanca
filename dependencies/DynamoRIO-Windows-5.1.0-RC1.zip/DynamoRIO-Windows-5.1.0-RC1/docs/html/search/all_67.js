var searchData=
[
  ['get_5fregister_5fname',['get_register_name',['../dr__ir__opnd_8h.html#a4b412ff3d08026f65ac44e1c6659a58a',1,'dr_ir_opnd.h']]],
  ['get_5fx86_5fmode',['get_x86_mode',['../dr__ir__utils_8h.html#aa18c8ca0720c97403a0fa9371ae792e5',1,'dr_ir_utils.h']]],
  ['global_5fdcontext',['GLOBAL_DCONTEXT',['../dr__tools_8h.html#a4e6bdc93e35ee5a9f081564a162ec3b9',1,'dr_tools.h']]],
  ['graphical_20application_20framework',['Graphical Application Framework',['../page_drgui.html',1,'page_ext']]]
];
