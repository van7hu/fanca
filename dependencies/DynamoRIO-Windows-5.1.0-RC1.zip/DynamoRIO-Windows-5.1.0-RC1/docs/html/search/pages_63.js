var searchData=
[
  ['code_20manipulation_20api',['Code Manipulation API',['../API_BT.html',1,'index']]],
  ['container_20data_20structures',['Container Data Structures',['../page_drcontainers.html',1,'page_ext']]],
  ['code_20coverage_20tool',['Code Coverage Tool',['../page_drcov.html',1,'page_tool']]],
  ['client_20transparency',['Client Transparency',['../transparency.html',1,'overview']]]
];
