var searchData=
[
  ['multi_2dinstrumentation_20manager',['Multi-Instrumentation Manager',['../group__drmgr.html',1,'']]]
];
