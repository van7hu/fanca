var searchData=
[
  ['app_5frva_5ft',['app_rva_t',['../dr__defines_8h.html#af9fff97e6e608cc681ebfd1793c772f6',1,'dr_defines.h']]]
];
