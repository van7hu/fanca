var searchData=
[
  ['ordinal',['ordinal',['../struct__dr__symbol__import__t.html#a5bb017f3f50671c289124207bdc47b62',1,'_dr_symbol_import_t::ordinal()'],['../struct__dr__symbol__export__t.html#a759b1083cf5780cdc2aa5017f0e03591',1,'_dr_symbol_export_t::ordinal()']]],
  ['our_5fstderr',['our_stderr',['../dr__defines_8h.html#a096153d4f8a4fffa5d2cabeecffc9540',1,'dr_defines.h']]],
  ['our_5fstdin',['our_stdin',['../dr__defines_8h.html#ac5d961a13c6ef71da452f84886cd3de5',1,'dr_defines.h']]],
  ['our_5fstdout',['our_stdout',['../dr__defines_8h.html#a49ff3685a627a273629e95fc78948e5a',1,'dr_defines.h']]]
];
