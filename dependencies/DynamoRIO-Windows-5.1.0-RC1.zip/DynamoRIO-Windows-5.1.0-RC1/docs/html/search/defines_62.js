var searchData=
[
  ['bb_5forigin_5fheader_5fsize',['BB_ORIGIN_HEADER_SIZE',['../dr__tools_8h.html#a7af2dcd801f468cdc1cce40f7e885ffc',1,'dr_tools.h']]]
];
