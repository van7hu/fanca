var searchData=
[
  ['vendor_5famd',['VENDOR_AMD',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da98f56d8179428f9ae8a673281e490fb7',1,'dr_proc.h']]],
  ['vendor_5farm',['VENDOR_ARM',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da2ad2ea2a2c40658bd0ded140cc6b8819',1,'dr_proc.h']]],
  ['vendor_5fintel',['VENDOR_INTEL',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da0ff85c91faaad5edc40b8b13bf5872a9',1,'dr_proc.h']]],
  ['vendor_5funknown',['VENDOR_UNKNOWN',['../dr__proc_8h.html#abc5c98fcc1211af2b80116dd6e0a035da366adf423d8e0771406dc7be013f0fce',1,'dr_proc.h']]]
];
