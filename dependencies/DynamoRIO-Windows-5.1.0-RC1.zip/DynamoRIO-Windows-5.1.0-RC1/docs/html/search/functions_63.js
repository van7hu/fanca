var searchData=
[
  ['create_5finstance',['create_instance',['../classdrgui__tool__interface__t.html#aa43851da86d170f6abf5c8c4ddbf05b6',1,'drgui_tool_interface_t']]],
  ['create_5foptions_5fpage',['create_options_page',['../classdrgui__tool__interface__t.html#a265d432ab2e13c15ef32a2075530afd3',1,'drgui_tool_interface_t']]]
];
