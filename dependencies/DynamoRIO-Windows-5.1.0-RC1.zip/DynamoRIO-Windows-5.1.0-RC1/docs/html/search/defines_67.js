var searchData=
[
  ['global_5fdcontext',['GLOBAL_DCONTEXT',['../dr__tools_8h.html#a4e6bdc93e35ee5a9f081564a162ec3b9',1,'dr_tools.h']]]
];
