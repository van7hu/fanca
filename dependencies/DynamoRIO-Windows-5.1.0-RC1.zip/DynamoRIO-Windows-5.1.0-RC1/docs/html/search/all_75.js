var searchData=
[
  ['umbra_3a_20shadow_20memory_20extension',['Umbra: Shadow Memory Extension',['../page_drmf_umbra.html',1,'page_ext']]],
  ['u32',['u32',['../union__dr__xmm__t.html#af0a46f92c051370505616885810d9e71',1,'_dr_xmm_t::u32()'],['../union__dr__ymm__t.html#a2032f99ae25e76ac235c6c5bbcc337a5',1,'_dr_ymm_t::u32()']]],
  ['u64',['u64',['../union__dr__xmm__t.html#a31e767d50402a3da7879062840e2a787',1,'_dr_xmm_t::u64()'],['../union__dr__ymm__t.html#ac74b1e9ebca778708598e6f5ca251e05',1,'_dr_ymm_t::u64()']]],
  ['u8',['u8',['../union__dr__xmm__t.html#a4de211ec7f13bd2daea07a1675f34ce2',1,'_dr_xmm_t::u8()'],['../union__dr__ymm__t.html#a86174600dfeb4d341f27b6111b50caa0',1,'_dr_ymm_t::u8()']]],
  ['use_5ferrno',['use_errno',['../struct__dr__syscall__result__info__t.html#a08c70526e7a3c63954234021129c1a90',1,'_dr_syscall_result_info_t']]],
  ['use_5fhigh',['use_high',['../struct__dr__syscall__result__info__t.html#a640d68c87a33d04d70f5680c845c5eae',1,'_dr_syscall_result_info_t']]],
  ['usage_20model_20for_20dynamorio',['Usage Model for DynamoRIO',['../using.html',1,'index']]]
];
