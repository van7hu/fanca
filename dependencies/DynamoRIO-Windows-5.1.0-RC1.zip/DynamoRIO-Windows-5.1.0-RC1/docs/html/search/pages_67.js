var searchData=
[
  ['graphical_20application_20framework',['Graphical Application Framework',['../page_drgui.html',1,'page_ext']]]
];
