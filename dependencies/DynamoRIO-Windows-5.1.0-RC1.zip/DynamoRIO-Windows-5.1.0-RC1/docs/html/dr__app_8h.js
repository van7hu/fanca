var dr__app_8h =
[
    [ "DR_APP_API", "dr__app_8h.html#aed3a0d825116498ae89b00c849129d4d", null ],
    [ "dr_app_cleanup", "dr__app_8h.html#a216ee7d3e25b4c31edf5a9b2ba93d533", null ],
    [ "dr_app_handle_mbr_target", "dr__app_8h.html#aba46eea03a20e5801b87b7cd54d26bf5", null ],
    [ "dr_app_running_under_dynamorio", "dr__app_8h.html#aea917a6c24c8bf526f77772b0b9848a8", null ],
    [ "dr_app_setup", "dr__app_8h.html#abcdedd068a4d264401c31767355ec218", null ],
    [ "dr_app_setup_and_start", "dr__app_8h.html#ace92a2658a46bb5811ece68ae964fd62", null ],
    [ "dr_app_start", "dr__app_8h.html#afb7b7aed03dd6f0ed8d48b8a8796e55e", null ],
    [ "dr_app_stop", "dr__app_8h.html#afd509bb9ea5d1947228de48dda256e8f", null ],
    [ "dr_app_take_over", "dr__app_8h.html#a43dead944cb3c75de2537404b568f8ec", null ]
];