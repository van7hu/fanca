var drtable_8h =
[
    [ "DRTABLE_INVALID_INDEX", "drtable_8h.html#gaeaba87af31694a825496218053177d64", null ],
    [ "drtable_flags_t", "drtable_8h.html#gabdc8e2396ab8607a7e4c1e5f05c588c3", [
      [ "DRTABLE_MEM_REACHABLE", "drtable_8h.html#ggabdc8e2396ab8607a7e4c1e5f05c588c3a8a428f6ca9cdbd75e3f9807d8e03379f", null ],
      [ "DRTABLE_MEM_32BIT", "drtable_8h.html#ggabdc8e2396ab8607a7e4c1e5f05c588c3adc74fb8cb16fc3a8a9fd8f898ee05d98", null ],
      [ "DRTABLE_ALLOC_COMPACT", "drtable_8h.html#ggabdc8e2396ab8607a7e4c1e5f05c588c3a3a762298e3f0d70895d7ba6602e6cfbe", null ]
    ] ],
    [ "drtable_alloc", "drtable_8h.html#ga1b426a61810d4725391304f51efd423c", null ],
    [ "drtable_create", "drtable_8h.html#ga2eac73999ae64ce7dab8617e7c3607dd", null ],
    [ "drtable_destroy", "drtable_8h.html#gab72aa8dc1faa57b8ac88cd8ead4ed006", null ],
    [ "drtable_dump_entries", "drtable_8h.html#gaca3d018db60aa066b151220ff9202d54", null ],
    [ "drtable_get_entry", "drtable_8h.html#gaed6dc346bbda6ed02e1065974242e1d4", null ],
    [ "drtable_get_index", "drtable_8h.html#ga061cb4a1744b6f075a515ed43ba166fb", null ],
    [ "drtable_iterate", "drtable_8h.html#ga1582acfe56f0ad7d8897e314aeea61fd", null ],
    [ "drtable_lock", "drtable_8h.html#gad164ad428e8e5d8927cd6ff0bb5566b5", null ],
    [ "drtable_num_entries", "drtable_8h.html#ga9ebd56f50630fd8e60c0a26037f8c35a", null ],
    [ "drtable_unlock", "drtable_8h.html#gab138f40390422527895eda77fb2d2dbb", null ]
];