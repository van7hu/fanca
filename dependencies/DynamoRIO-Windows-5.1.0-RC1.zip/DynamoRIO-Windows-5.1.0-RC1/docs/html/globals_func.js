var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "d", "globals_func_0x64.html", null ],
    [ "g", "globals_func_0x67.html", null ],
    [ "h", "globals_func_0x68.html", null ],
    [ "i", "globals_func_0x69.html", null ],
    [ "o", "globals_func_0x6f.html", null ],
    [ "p", "globals_func_0x70.html", null ],
    [ "r", "globals_func_0x72.html", null ],
    [ "s", "globals_func_0x73.html", null ]
];